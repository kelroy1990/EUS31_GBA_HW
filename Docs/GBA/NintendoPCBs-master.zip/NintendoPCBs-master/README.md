# [Make sure you read the License before downloading anything!](https://github.com/HDR/NintendoPCBs/blob/master/LICENSE)

Please see the [wiki](https://github.com/HDR/NintendoPCBs/wiki) for additional information.


See the [Nintendo Board Scans](https://github.com/HDR/Nintendo_Board_Scans) for more.
